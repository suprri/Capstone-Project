import numpy as np
import pandas as pd
from flask import Flask, render_template, request
import pickle

from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)
tfidf = pickle.load(open("model.pkl", "rb"))

emiten = pd.read_csv("Ringkasan Saham v3.csv")


def important_features(emiten):
    dfemiten = emiten.copy()
    for i in range(0, emiten.shape[0]):
        dfemiten["fitur"] = dfemiten["papanPencatatan"]+' '+dfemiten["Sektor"]+" " + \
            dfemiten["Gainers"]+" "+dfemiten["Volume"] + \
            " "+dfemiten["Nilai"]+" "+dfemiten["Freq"]
    return dfemiten


dfemiten = important_features(emiten)
dfemiten["item"] = [i for i in range(0, dfemiten.shape[0])]


def recommend(title):
    recEmiten = dfemiten[dfemiten.NamaPerusahaan == title]["item"].values[0]
    rating = list(enumerate(cos[recEmiten]))
    recRating = sorted(rating, key=lambda x: x[1], reverse=True)
    racReting = recRating[1:]
    emiten = [dfemiten[emiten[0] == dfemiten["item"]]
              ["NamaPerusahaan"].values[0] for emiten in recRating]
    # emiten = [dfemiten[emiten[0] == dfemiten["item"]][["NamaPerusahaan", "Sektor"]].values[0] for emiten in recRating]
    return emiten


def recommend_ten(nEmiten):
    rec10 = []
    count = 0
    for recom in nEmiten:
        if count > 10:
            break
        count += 1
        rec10.append(recom)
    return rec10


cos = cosine_similarity(tfidf)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    predict = recommend(request.form['txtName'])
    rekomendasi = recommend_ten(predict)
    for i in rekomendasi:
        print(i)
    # rekomendasi
    return render_template("index.html", prediction_text="{}".format(rekomendasi))


if __name__ == "__main__":
    app.run(debug=True)
